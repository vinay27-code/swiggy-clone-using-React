 export const groceryGridCards= [{
                                                "id": "6821bc9e09ab2e00019aa5d1",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2025/5/14/43e3c412-4ca9-4894-82ba-24b69da80aa6_06c0d2a9-804c-4bf1-8725-7ebd234e144a",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Fresh Vegetables",
                                                    "text": "Fresh Vegetables",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "6821bc9e09ab2e00019aa5d1",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Fresh Vegetables",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "6821facbeb76ab0001691ddb",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2025/5/14/a1493d81-f21e-415f-9875-f78383590fc2_9f3f0f68-4fbe-40f6-8f5d-5472a03469bd",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Fresh Fruits",
                                                    "text": "Fresh Fruits",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "6821facbeb76ab0001691ddb",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Fresh Fruits",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "681f4d69eb76ab0001691dc9",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2025/5/14/6dea6676-ce07-45e6-b60c-a099c01c5462_6d33297a-5828-48ff-aa2a-c052ae97669e",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Dairy, Bread and Eggs",
                                                    "text": "Dairy, Bread and Eggs",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "681f4d69eb76ab0001691dc9",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Dairy, Bread and Eggs",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "681de790cc67390001a095d2",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2025/5/14/097900ca-5d2d-4bb0-8e54-aede1e58dfd8_eab3796c-ac17-48fd-bfc7-6356c6f89783",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Rice, Atta and Dals",
                                                    "text": "Rice, Atta and Dals",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "681de790cc67390001a095d2",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Rice, Atta and Dals",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "68219298cc67390001a095d8",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2025/5/14/64714677-e6b6-41c1-b533-6644d43e55f7_76ef86af-0483-41a5-8387-37901bf4ca6a",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Masalas and Dry Fruits",
                                                    "text": "Masalas and Dry Fruits",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "68219298cc67390001a095d8",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Masalas and Dry Fruits",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "682038cdbbe7600001aae469",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2025/5/14/8e48ee13-3b51-49ea-b765-5cf3e7a97c04_695caa8a-c2f6-4a1a-9672-53213fea21aa",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Oils and Ghee",
                                                    "text": "Oils and Ghee",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "682038cdbbe7600001aae469",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Oils and Ghee",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "68233862667b3c0001eb34ac",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2024/7/6/73e018a7-d342-475e-aaca-ec5cd3d0c59f_228ff3d4-ff21-44db-9768-7a369c65ce6a",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Munchies",
                                                    "text": "Munchies",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "68233862667b3c0001eb34ac",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Munchies",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "6824881fcc67390001a095f0",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2024/7/6/83a9b71b-1db7-4cbe-a9f7-ead650d26326_3afbe8c8-f5c8-4dd7-8357-f5711f80646b",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Sweet Tooth",
                                                    "text": "Sweet Tooth",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "6824881fcc67390001a095f0",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Sweet Tooth",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "681f455abbe7600001aae467",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2024/7/6/37d399b1-52d2-47ef-bdd8-8951e51819fc_0361a93d-e864-49be-a57d-46c958eb7b56",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Cold Drinks and Juices",
                                                    "text": "Cold Drinks and Juices",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "681f455abbe7600001aae467",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Cold Drinks and Juices",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "681f386909ab2e00019aa588",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2024/7/6/76a7104c-0f11-4182-aa51-0d48efc2be7f_aae098f9-aaff-4504-a222-bf13595d58cd",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Biscuits and Cakes",
                                                    "text": "Biscuits and Cakes",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "681f386909ab2e00019aa588",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Biscuits and Cakes",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "6820a87b09ab2e00019aa5c4",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2025/5/14/1a08f110-17b6-4785-92d4-404825b75f2d_869c1986-d9c1-4d46-b1c3-10c79a052a59",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Instant and Frozen Food",
                                                    "text": "Instant and Frozen Food",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "6820a87b09ab2e00019aa5c4",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Instant and Frozen Food",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "6821a0a01f249300018d7735",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2025/5/14/25be4b2d-a9de-495e-a9a4-9a6d6a3d13c0_5f571281-eef0-4820-9982-d8bdd9af91c6",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Meat and Seafood",
                                                    "text": "Meat and Seafood",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "6821a0a01f249300018d7735",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Meat and Seafood",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "681f386909ab2e00019aa595",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2025/5/14/012beae1-c31a-4360-9b32-173080b64652_aa07a04e-5f2e-4c00-86f6-297344906f01",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Cereals and Breakfast",
                                                    "text": "Cereals and Breakfast",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "681f386909ab2e00019aa595",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Cereals and Breakfast",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "68247a48cc67390001a095ee",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2024/7/6/e2f96940-2657-4a4b-a5e1-0c3413ba25cb_8b977351-a415-442a-bb9c-320e1642f740",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Sauces and Spreads",
                                                    "text": "Sauces and Spreads",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "68247a48cc67390001a095ee",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Sauces and Spreads",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "682496711f249300018d774c",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2025/5/14/5fc3d15a-26b0-41e0-93ab-39ada0f553c2_82e0ff9f-558c-45dd-af3e-fdc16d0aa471",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Tea, Coffee and More",
                                                    "text": "Tea, Coffee and More",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "682496711f249300018d774c",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Tea, Coffee and More",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "681f386909ab2e00019aa5a3",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2024/7/6/73a47bc4-c684-447f-9908-22da3ecd3ba2_c9948a61-3dca-4e29-82b4-31178d38746b",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Cleaning Essentials",
                                                    "text": "Cleaning Essentials",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "681f386909ab2e00019aa5a3",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Cleaning Essentials",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "682058d4bbe7600001aae473",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2025/5/14/fc74f557-a203-4dba-8955-82d6c608e91e_7d2481f0-8614-400c-b25c-554a655c14c7",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Pharma and Hygiene",
                                                    "text": "Pharma and Hygiene",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "682058d4bbe7600001aae473",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Pharma and Hygiene",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "681f386909ab2e00019aa57e",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2024/7/6/4342c814-6ff9-4bbe-a360-95200ad602a0_1905dc17-a04d-4a9e-9a4e-adde9b27f321",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Bath, Body and Hair",
                                                    "text": "Bath, Body and Hair",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "681f386909ab2e00019aa57e",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Bath, Body and Hair",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "682462130c0f930001b218a0",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2025/3/25/1eae2df9-95a5-40e5-a2c0-92bb4893637a_5e1e6c72-dde5-4a12-8bdf-c7cbc4b0644b",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Paan Corner",
                                                    "text": "Paan Corner",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "682462130c0f930001b218a0",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Paan Corner",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "6820a87b09ab2e00019aa5ae",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2025/5/14/657a922d-067a-4e0b-b967-b3e0c7906fa9_485311db-2f22-4193-a05d-963f18a89150",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Home and Kitchen",
                                                    "text": "Home and Kitchen",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "6820a87b09ab2e00019aa5ae",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Home and Kitchen",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "68234e9509ab2e00019aa696",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2025/5/14/52a66c89-6516-489f-96ac-b15286900648_ebbfd2d1-9b36-4ce3-b08c-7378f1ca6d7d",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Office and Electricals",
                                                    "text": "Office and Electricals",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "68234e9509ab2e00019aa696",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Office and Electricals",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "681f386909ab2e00019aa576",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2024/7/6/cbbab04b-845a-44bd-aa63-329276af1714_c6c9dc53-ae50-475a-89d8-b03824c4a98a",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Baby Care",
                                                    "text": "Baby Care",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "681f386909ab2e00019aa576",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Baby Care",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "682462130c0f930001b218ab",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2025/5/14/705173ff-7cd9-4d7e-9e5b-3886d81411b9_bb324827-9556-48e4-b8f6-280706478fe2",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Pet Supplies",
                                                    "text": "Pet Supplies",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "682462130c0f930001b218ab",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Pet Supplies",
                                                "overlayIcon": {}
                                            }, {
                                                "id": "682316f5667b3c0001eb34a1",
                                                "imageId": "NI_CATALOG/IMAGES/CIW/2025/5/14/e160e4c4-2114-4e3d-97ff-3922125a3b2e_224bcfa1-77e3-47e5-aea5-1ab060585b4b",
                                                "action": {
                                                    "link": "https://www.swiggy.com/instamart/category-listing?categoryName=Beauty and Grooming",
                                                    "text": "Beauty and Grooming",
                                                    "type": "DEEPLINK"
                                                },
                                                "accessibility": {},
                                                "entityId": "682316f5667b3c0001eb34a1",
                                                "frequencyCapping": {},
                                                "externalMarketing": {},
                                                "description": "Beauty and Grooming",
                                                "overlayIcon": {}
                                            }]